---
layout: post
title: Another Post Example
author: ExchangeRate-API
date: 2016-09-06
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam imperdiet urna eu dolor placerat varius. Vivamus eros augue, consequat id scelerisque nec, fringilla in est. Proin pellentesque malesuada mauris, quis aliquam augue vestibulum ac.

# Header

# Header 1

## Header 2

### Header 3

#### Header 4

##### Header 5

###### Header 6

Some example text, okay? It's normal, right? :)

There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.

**bold text**

*italic text*

> And this is a blockquote

~~~
And this is a source code in a block
Yeah, don't use highligth :D
~~~

But if you like `inline code`, it's fine.

And, of course, links: [lampiaosec].

# Lists

* Item x
* Item z

1. Item 01
2. Item 02

## Table of content

* toc
{:toc}
